import { Task } from "./task";

export const TASKS:Task[] =[
    {taskId:'101',taskTitle:'Hello',taskDescription:'hi',taskDeadline:'22-12-2022',taskPriority:'high',assignee:'Harry'},
    {taskId:'102',taskTitle:'Bye',taskDescription:'See u ',taskDeadline:'25-12-2022',taskPriority:'low',assignee:'Kunal'}
]