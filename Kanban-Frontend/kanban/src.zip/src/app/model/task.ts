export type Task = {
    taskId?: string;
    taskTitle?: string;
    taskDescription?: string;
    taskDeadline?: string;
    taskPriority?: string;
    assignee?: string;
}