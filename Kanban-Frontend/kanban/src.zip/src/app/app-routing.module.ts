import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddTaskComponent } from './add-task/add-task.component';

import { DragComponent } from './drag/drag.component';
import { EditTaskComponent } from './edit-task/edit-task.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [{
  path: "login",
  component: LoginComponent
},
{
  path: "register",
  component: RegistrationComponent
},
{
  path: "dashboard",
  component: DragComponent
},
{
  path: "add-task",
  component: AddTaskComponent
},
{
  path: "edit-task/:taskId",
  component: EditTaskComponent
},
{
  path: "",
  redirectTo: "/login",
  pathMatch: "full"
},
{
  path: "**",
  component: PageNotFoundComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
