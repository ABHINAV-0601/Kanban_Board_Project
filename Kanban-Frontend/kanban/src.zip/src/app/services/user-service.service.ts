import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private httpClient:HttpClient) { }

  url:String = "http://localhost:9000/userdata"

  addUser(userObject:any){
    return  this.httpClient.post(this.url+"/register",userObject);
  }

  url2:String = "http://localhost:9000/authdata"

  login(object:any){
    return this.httpClient.post(this.url2+"/login",object);
  }
}
