package com.niit.user_service.service;

import com.niit.user_service.domain.User;
import com.niit.user_service.exception.UserAlreadyExistsException;
import com.niit.user_service.proxy.UserProxy;
import com.niit.user_service.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserProxy userProxy;
    @Autowired
    private JavaMailSender javaMailSender;
    @Override
    public User saveUser(User user) throws UserAlreadyExistsException {
        if(userRepository.findById(user.getEmailId()).isPresent()){
            throw new UserAlreadyExistsException();
        }
        User user1 = userRepository.save(user);
        if(!(user1.getEmailId().isEmpty())){
            ResponseEntity responseEntity = userProxy.saveUser(user);
            System.out.println(responseEntity.getBody());
        }
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(user.getEmailId());
        msg.setSubject("Registration");
        msg.setText("You have registered successfully. You can now login!!");
        javaMailSender.send(msg);
        return user1;
    }
}
