package com.niit.user_service.controller;

import com.niit.user_service.domain.User;
import com.niit.user_service.exception.UserAlreadyExistsException;
import com.niit.user_service.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/userdata")

public class UserController {

    private ResponseEntity responseEntity;
    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> addUser(@RequestBody User user) throws UserAlreadyExistsException {
        try{
            user.setTaskList(new ArrayList<>());
            responseEntity = new ResponseEntity<>(userService.saveUser(user), HttpStatus.CREATED);
        }catch (UserAlreadyExistsException exception){
            throw new UserAlreadyExistsException();
        }catch(Exception exception){
            responseEntity = new ResponseEntity<>(exception.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }
}
